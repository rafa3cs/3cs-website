import { useEffect, useRef } from 'react';
import { Search, Monitor, Zap, UserCheck } from 'lucide-react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const engagements = [
  {
    icon: Search,
    title: 'Truth Scan',
    duration: '2-3 semanas',
    description:
      'Diagnóstico rápido. Encontra onde o capital está vazando. Taxa fixa. Descobertas claras. Sem compromisso de longo prazo.',
    features: ['Análise de fluxo de caixa', 'Check-up de saúde do estoque', 'Identificação de gaps de processo', 'Recomendações acionáveis'],
  },
  {
    icon: Monitor,
    title: 'Decision Dashboards',
    duration: '30 dias',
    description:
      'Preços, estoque, merchandising, planos financeiros. Construídos com seus dados. Prontos para decisão e adaptados ao seu negócio.',
    features: ['Métricas em tempo real', 'Acompanhamento de KPIs customizados', 'Visibilidade cross-funcional', 'Alertas automatizados'],
  },
  {
    icon: Zap,
    title: 'Sprint de Recuperação 90 Dias',
    duration: '90 dias',
    description:
      'Execução focada. Antes e depois claros. Steerings semanais. Resultados mensuráveis com suporte dedicado.',
    features: ['Chamadas de steering semanais', 'Acompanhamento de milestones', 'Correções de curso', 'Garantia de resultados'],
  },
  {
    icon: UserCheck,
    title: 'Assessoria Embutida',
    duration: 'Contínuo',
    description:
      'CFO/COO-as-a-Service. Para empresas que precisam de pensamento sênior sem custo de tempo integral.',
    features: ['Retainers mensais', 'Expertise sob demanda', 'Relatórios para board', 'Planejamento estratégico'],
  },
];

const Engagement = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const headerRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement[]>([]);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Header animation
      gsap.fromTo(
        headerRef.current,
        { y: 40, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.6,
          ease: 'expo.out',
          scrollTrigger: {
            trigger: headerRef.current,
            start: 'top 80%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Cards deal from deck animation
      cardsRef.current.forEach((card, index) => {
        gsap.fromTo(
          card,
          { 
            rotateX: -30,
            y: 100,
            opacity: 0,
          },
          {
            rotateX: 0,
            y: 0,
            opacity: 1,
            duration: 0.7,
            ease: 'back.out(1.2)',
            scrollTrigger: {
              trigger: card,
              start: 'top 90%',
              toggleActions: 'play none none reverse',
            },
            delay: index * 0.12,
          }
        );
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="engagement"
      className="relative w-full py-32 bg-[#151515]"
    >
      {/* Background Visual */}
      <div className="absolute inset-0 opacity-15 pointer-events-none">
        <img
          src="/data-visual-2.jpg"
          alt=""
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-[#151515] via-[#151515]/80 to-[#151515]" />
      </div>

      <div className="relative z-10 w-full px-6 lg:px-12">
        {/* Header */}
        <div ref={headerRef} className="text-center mb-20" style={{ opacity: 0 }}>
          <div className="section-label">[ FORMATOS DE ENGAGEMENT ]</div>
          <h2 className="text-h2 text-white">Como Engajamos</h2>
          <p className="text-lg text-[#999] max-w-2xl mx-auto mt-6">
            Engajamentos claros e contidos. Sem consultoria sem fim. 
            Cada formato projetado para resultados mensuráveis.
          </p>
        </div>

        {/* Cards */}
        <div 
          className="grid md:grid-cols-2 gap-6 max-w-6xl mx-auto"
          style={{ perspective: '1200px' }}
        >
          {engagements.map((engagement, index) => {
            const Icon = engagement.icon;

            return (
              <div
                key={index}
                ref={(el) => { if (el) cardsRef.current[index] = el; }}
                className="group"
                style={{ 
                  opacity: 0,
                  transformStyle: 'preserve-3d',
                }}
              >
                <div 
                  className="card-dark h-full flex flex-col hover:translate-y-[-15px] hover:scale-[1.02] transition-all duration-350"
                  style={{
                    boxShadow: `
                      0 10px 30px rgba(0,0,0,0.3),
                      0 30px 60px rgba(0,0,0,0.2),
                      0 60px 100px rgba(0,0,0,0.1)
                    `,
                  }}
                >
                  {/* Header */}
                  <div className="flex items-start justify-between mb-6">
                    <div className="w-14 h-14 flex items-center justify-center border border-[#333] group-hover:border-[#666] group-hover:rotate-[15deg] transition-all duration-400">
                      <Icon size={28} className="text-[#999] group-hover:text-white transition-colors duration-300" />
                    </div>
                    <div 
                      className="px-4 py-2 border border-[#333] text-mono text-[#999] group-hover:border-[#666] group-hover:text-white transition-all duration-300"
                      style={{
                        animation: `badgePulse 3s ease-in-out infinite`,
                        animationDelay: `${index * 0.5}s`,
                      }}
                    >
                      {engagement.duration}
                    </div>
                  </div>

                  {/* Content */}
                  <h3 className="text-h4 text-white mb-4">{engagement.title}</h3>
                  <p className="text-[#999] leading-relaxed mb-6 group-hover:text-[#aaa] transition-colors duration-300">
                    {engagement.description}
                  </p>

                  {/* Features */}
                  <ul className="space-y-2 mt-auto">
                    {engagement.features.map((feature, fIndex) => (
                      <li
                        key={fIndex}
                        className="flex items-center gap-3 text-sm text-[#999] group-hover:text-[#aaa] transition-colors duration-300"
                      >
                        <div className="w-1 h-1 bg-[#666] group-hover:bg-white transition-colors duration-300" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default Engagement;
