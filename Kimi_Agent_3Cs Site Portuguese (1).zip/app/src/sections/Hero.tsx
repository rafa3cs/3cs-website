import { useEffect, useRef } from 'react';
import { ArrowRight } from 'lucide-react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const Hero = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const labelRef = useRef<HTMLDivElement>(null);
  const headlineRefs = useRef<HTMLDivElement[]>([]);
  const subheadlineRef = useRef<HTMLParagraphElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      const tl = gsap.timeline({ defaults: { ease: 'expo.out' } });

      // Background image fade in
      tl.fromTo(
        imageRef.current,
        { opacity: 0, scale: 1.1 },
        { opacity: 1, scale: 1, duration: 1.2 }
      );

      // Label clip reveal
      tl.fromTo(
        labelRef.current,
        { clipPath: 'inset(0 100% 0 0)', letterSpacing: '0.2em' },
        { clipPath: 'inset(0 0% 0 0)', letterSpacing: '0.1em', duration: 0.6 },
        '-=0.8'
      );

      // Headline lines staggered rise
      headlineRefs.current.forEach((line, index) => {
        tl.fromTo(
          line,
          { y: 80, opacity: 0, rotateX: -40 },
          { y: 0, opacity: 1, rotateX: 0, duration: 0.8, ease: 'back.out(1.2)' },
          `-=${0.68 - index * 0.12}`
        );
      });

      // Subheadline blur fade
      tl.fromTo(
        subheadlineRef.current,
        { opacity: 0, y: 30, filter: 'blur(10px)' },
        { opacity: 1, y: 0, filter: 'blur(0px)', duration: 0.7, ease: 'power2.out' },
        '-=0.4'
      );

      // CTAs
      if (ctaRef.current?.children[0]) {
        tl.fromTo(
          ctaRef.current.children[0],
          { scale: 0.8, opacity: 0 },
          { scale: 1, opacity: 1, duration: 0.5, ease: 'elastic.out(1, 0.5)' },
          '-=0.2'
        );
      }

      if (ctaRef.current?.children[1]) {
        tl.fromTo(
          ctaRef.current.children[1],
          { x: -50, opacity: 0 },
          { x: 0, opacity: 1, duration: 0.5 },
          '-=0.3'
        );
      }

      // Scroll-triggered fade out for content
      gsap.to(contentRef.current, {
        opacity: 0,
        y: -100,
        ease: 'none',
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top top',
          end: '50% top',
          scrub: true,
        },
      });

      // Parallax for background image
      gsap.to(imageRef.current, {
        y: 100,
        ease: 'none',
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top top',
          end: 'bottom top',
          scrub: true,
        },
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      ref={sectionRef}
      className="relative min-h-screen w-full overflow-hidden bg-[#151515]"
    >
      {/* Background Image */}
      <div
        ref={imageRef}
        className="absolute inset-0 z-0"
        style={{ opacity: 0 }}
      >
        <img
          src="/hero-bg-new.jpg"
          alt="Equipe executiva analisando dados"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#151515] via-[#151515]/70 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#151515] via-transparent to-[#151515]/60" />
      </div>

      {/* Floating Particles */}
      <div className="absolute inset-0 z-[1] pointer-events-none overflow-hidden">
        {[...Array(15)].map((_, i) => (
          <div
            key={i}
            className="absolute w-1 h-1 bg-white/30 rounded-full"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animation: `float ${15 + Math.random() * 10}s ease-in-out infinite`,
              animationDelay: `${Math.random() * 5}s`,
            }}
          />
        ))}
      </div>

      {/* Content */}
      <div ref={contentRef} className="relative z-10 min-h-screen flex items-center">
        <div className="w-full px-6 lg:px-12 py-32">
          <div className="max-w-4xl" style={{ perspective: '1200px' }}>
            {/* Label */}
            <div
              ref={labelRef}
              className="text-mono text-[#999] mb-8"
              style={{ clipPath: 'inset(0 100% 0 0)' }}
            >
              [ INTELIGÊNCIA DE DECISÃO ]
            </div>

            {/* Headline */}
            <h1 className="text-h1 text-white mb-8" style={{ transformStyle: 'preserve-3d' }}>
              <div
                ref={(el) => { if (el) headlineRefs.current[0] = el; }}
                className="overflow-hidden"
                style={{ opacity: 0 }}
              >
                Reduzindo Surpresas.
              </div>
              <div
                ref={(el) => { if (el) headlineRefs.current[1] = el; }}
                className="overflow-hidden"
                style={{ opacity: 0 }}
              >
                Tornando Trade-offs
              </div>
              <div
                ref={(el) => { if (el) headlineRefs.current[2] = el; }}
                className="overflow-hidden"
                style={{ opacity: 0 }}
              >
                Explícitos.
              </div>
            </h1>

            {/* Subheadline */}
            <p
              ref={subheadlineRef}
              className="text-lg lg:text-xl text-[#999] max-w-2xl mb-12 leading-relaxed"
              style={{ opacity: 0 }}
            >
              Alinhamos Finanças, Operações e Estratégia Comercial para que empresas 
              passem da gestão baseada em intuição para a execução guiada por disciplina.
            </p>

            {/* CTAs */}
            <div ref={ctaRef} className="flex flex-wrap gap-4">
              <button
                onClick={() => scrollToSection('#method')}
                className="btn-primary group"
              >
                Veja Como Trabalhamos
                <ArrowRight
                  size={16}
                  className="transition-transform duration-300 group-hover:translate-x-2"
                />
              </button>
              <button
                onClick={() => scrollToSection('#capabilities')}
                className="btn-secondary"
              >
                Explore o Método
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Gradient */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-[#151515] to-transparent z-10" />
    </section>
  );
};

export default Hero;
