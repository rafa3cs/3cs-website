import { useEffect, useRef, useState } from 'react';
import { Store, Factory, Rocket, Users, ArrowRight } from 'lucide-react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const audiences = [
  {
    icon: Store,
    title: 'Varejo e Bens de Consumo',
    shortDesc: 'Onde o estoque é tanto oportunidade quanto risco.',
    fullDesc: 'Empresas navegando o equilíbrio complexo entre disponibilidade de estoque e eficiência de capital. Ajudamos a otimizar toda a cadeia de valor desde a compra até o ponto de venda.',
    stats: ['30% giro de estoque mais rápido', '25% redução em rupturas'],
  },
  {
    icon: Factory,
    title: 'Negócios Capital-Intensivos',
    shortDesc: 'Onde fluxo de caixa e disciplina de margem determinam sobrevivência.',
    fullDesc: 'Empresas com requisitos significativos de capital de giro. Trazemos disciplina financeira para decisões operacionais, garantindo que cada dólar trabalhe mais.',
    stats: ['20% melhoria no CCC', '15% aumento no fluxo de caixa'],
  },
  {
    icon: Rocket,
    title: 'PMEs em Crescimento Acelerado',
    shortDesc: 'Crescimento superou sistemas. Decisões precisam de estrutura.',
    fullDesc: 'Empresas em crescimento rápido que precisam de disciplina de nível enterprise sem overhead enterprise. Fornecemos os frameworks que escalam com você.',
    stats: ['2x velocidade de decisão', '40% menos surpresas'],
  },
  {
    icon: Users,
    title: 'Fundadores, CEOs, CFOs',
    shortDesc: 'Líderes cansados de gestão reativa.',
    fullDesc: 'Executivos que querem passar do combate a incêndios para execução estratégica. Fornecemos a visibilidade e controle necessários para tomada de decisão confiante.',
    stats: ['Visibilidade em tempo real', 'Alertas proativos'],
  },
];

const WhoItsFor = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const headerRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement[]>([]);
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Header animation
      gsap.fromTo(
        headerRef.current,
        { y: 40, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.6,
          ease: 'expo.out',
          scrollTrigger: {
            trigger: headerRef.current,
            start: 'top 80%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Cards animation
      cardsRef.current.forEach((card, index) => {
        gsap.fromTo(
          card,
          { y: 60, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            duration: 0.7,
            ease: 'back.out(1.2)',
            scrollTrigger: {
              trigger: card,
              start: 'top 85%',
              toggleActions: 'play none none reverse',
            },
            delay: index * 0.1,
          }
        );
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="relative w-full py-32 bg-[#151515] overflow-hidden"
    >
      <div className="relative z-10 w-full px-6 lg:px-12">
        {/* Header */}
        <div ref={headerRef} className="text-center mb-20" style={{ opacity: 0 }}>
          <div className="section-label">[ PÚBLICO-ALVO ]</div>
          <h2 className="text-h2 text-white">Para Quem É</h2>
        </div>

        {/* Cards Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
          {audiences.map((audience, index) => {
            const Icon = audience.icon;
            const isHovered = hoveredIndex === index;

            return (
              <div
                key={index}
                ref={(el) => { if (el) cardsRef.current[index] = el; }}
                className="group relative"
                style={{ opacity: 0 }}
                onMouseEnter={() => setHoveredIndex(index)}
                onMouseLeave={() => setHoveredIndex(null)}
              >
                <div 
                  className={`relative h-[400px] border border-[#333] bg-[#151515] overflow-hidden transition-all duration-500 ${
                    isHovered ? 'border-[#666]' : ''
                  }`}
                >
                  {/* Default Content */}
                  <div 
                    className={`absolute inset-0 p-6 flex flex-col transition-all duration-500 ${
                      isHovered ? 'opacity-0 translate-y-[-20px]' : 'opacity-100 translate-y-0'
                    }`}
                  >
                    {/* Icon */}
                    <div className="w-12 h-12 flex items-center justify-center border border-[#333] mb-6 group-hover:border-[#666] transition-colors duration-300">
                      <Icon size={24} className="text-[#999] group-hover:text-white transition-colors duration-300" />
                    </div>

                    {/* Title */}
                    <h3 className="text-lg font-medium text-white mb-4">
                      {audience.title}
                    </h3>

                    {/* Short Description */}
                    <p className="text-sm text-[#999] leading-relaxed flex-1">
                      {audience.shortDesc}
                    </p>

                    {/* Hover Hint */}
                    <div className="flex items-center gap-2 text-mono text-[#666] mt-4">
                      <span>Saiba mais</span>
                      <ArrowRight size={14} className="transition-transform duration-300 group-hover:translate-x-1" />
                    </div>
                  </div>

                  {/* Hover Content */}
                  <div 
                    className={`absolute inset-0 p-6 flex flex-col bg-[#1a1a1a] transition-all duration-500 ${
                      isHovered ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-[20px]'
                    }`}
                  >
                    {/* Icon */}
                    <div className="w-12 h-12 flex items-center justify-center border border-[#666] mb-6">
                      <Icon size={24} className="text-white" />
                    </div>

                    {/* Title */}
                    <h3 className="text-lg font-medium text-white mb-4">
                      {audience.title}
                    </h3>

                    {/* Full Description */}
                    <p className="text-sm text-[#999] leading-relaxed mb-6">
                      {audience.fullDesc}
                    </p>

                    {/* Stats */}
                    <div className="mt-auto space-y-2">
                      {audience.stats.map((stat, sIndex) => (
                        <div 
                          key={sIndex}
                          className="flex items-center gap-2 text-sm"
                        >
                          <div className="w-1.5 h-1.5 bg-white" />
                          <span className="text-white">{stat}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Border Glow Effect */}
                  <div 
                    className={`absolute inset-0 pointer-events-none transition-opacity duration-500 ${
                      isHovered ? 'opacity-100' : 'opacity-0'
                    }`}
                    style={{
                      boxShadow: 'inset 0 0 40px rgba(255,255,255,0.05)',
                    }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default WhoItsFor;
