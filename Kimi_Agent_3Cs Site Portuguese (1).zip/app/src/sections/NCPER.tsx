import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const ncperSteps = [
  {
    letter: 'N',
    word: 'Necessidade',
    title: 'Que problema realmente precisa ser resolvido?',
    description:
      'Começamos com a restrição real, não a assumida. Entendendo a verdadeira necessidade antes de qualquer solução ser proposta.',
    image: '/data-visual-1.jpg',
  },
  {
    letter: 'C',
    word: 'Capacidade',
    title: 'Pessoas, sistemas e capital suportam isso?',
    description:
      'Avaliamos prontidão, não apenas desejo. Capacidades devem estar alinhadas com ambições para execução sustentável.',
    image: '/data-visual-2.jpg',
  },
  {
    letter: 'P',
    word: 'Possibilidade',
    title: 'O que é viável agora, não teoricamente?',
    description:
      'Focamos em movimentos executáveis, não planos perfeitos. Possibilidade prática direciona nossas recomendações.',
    image: '/data-visual-3.jpg',
  },
  {
    letter: 'E',
    word: 'Esforço',
    title: 'Qual é o custo operacional e organizacional?',
    description:
      'Tornamos trade-offs explícitos antes de comprometer. Todo esforço deve ser justificado pelo seu retorno.',
    image: '/data-visual-1.jpg',
  },
  {
    letter: 'R',
    word: 'Retorno',
    title: 'Caixa, margem, risco, previsibilidade.',
    description:
      'Definimos sucesso em termos financeiros mensuráveis. Retorno é a validação final de qualquer decisão.',
    image: '/data-visual-2.jpg',
  },
];

const NCPER = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const headerRef = useRef<HTMLDivElement>(null);
  const stepsRef = useRef<HTMLDivElement[]>([]);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Header animation
      gsap.fromTo(
        headerRef.current,
        { y: 50, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.6,
          ease: 'expo.out',
          scrollTrigger: {
            trigger: headerRef.current,
            start: 'top 80%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Steps animation - alternating left-right
      stepsRef.current.forEach((step, index) => {
        const isLeft = index % 2 === 0;
        gsap.fromTo(
          step,
          { 
            x: isLeft ? -80 : 80,
            opacity: 0 
          },
          {
            x: 0,
            opacity: 1,
            duration: 0.8,
            ease: 'expo.out',
            scrollTrigger: {
              trigger: step,
              start: 'top 80%',
              toggleActions: 'play none none reverse',
            },
          }
        );
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="method"
      className="relative w-full py-32 bg-[#151515] overflow-hidden"
    >
      {/* Grid Background */}
      <div className="absolute inset-0 opacity-5 pointer-events-none">
        <div
          className="w-full h-full"
          style={{
            backgroundImage: `
              linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px),
              linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)
            `,
            backgroundSize: '50px 50px',
          }}
        />
      </div>

      <div className="relative z-10 w-full px-6 lg:px-12">
        {/* Header */}
        <div ref={headerRef} className="text-center mb-20" style={{ opacity: 0 }}>
          <div className="section-label">[ O MÉTODO ]</div>
          <h2 className="text-h2 text-white mb-6">NCPER: Uma Lente de Decisão</h2>
          <p className="text-lg text-[#999] max-w-2xl mx-auto">
            Cada engajamento segue cinco perguntas. Não frameworks. Não teoria. 
            Apenas pensamento disciplinado que leva à ação.
          </p>
        </div>

        {/* Steps - Alternating Layout */}
        <div className="max-w-6xl mx-auto space-y-16 lg:space-y-24">
          {ncperSteps.map((step, index) => {
            const isLeft = index % 2 === 0;

            return (
              <div
                key={index}
                ref={(el) => { if (el) stepsRef.current[index] = el; }}
                className={`grid lg:grid-cols-2 gap-8 lg:gap-16 items-center ${
                  isLeft ? '' : 'lg:direction-rtl'
                }`}
                style={{ opacity: 0 }}
              >
                {/* Image Side */}
                <div className={`relative overflow-hidden group ${isLeft ? 'lg:order-1' : 'lg:order-2'}`}>
                  <div className="aspect-[4/3] relative overflow-hidden">
                    <img
                      src={step.image}
                      alt={step.word}
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#151515]/60 to-transparent" />
                  </div>
                  {/* Letter Overlay */}
                  <div className="absolute bottom-4 left-4 w-16 h-16 flex items-center justify-center bg-white text-black text-3xl font-medium">
                    {step.letter}
                  </div>
                </div>

                {/* Content Side */}
                <div className={`${isLeft ? 'lg:order-2' : 'lg:order-1'}`}>
                  <div className="text-mono text-[#666] mb-4">{step.word}</div>
                  <h3 className="text-h3 text-white mb-6">{step.title}</h3>
                  <p className="text-lg text-[#999] leading-relaxed">
                    {step.description}
                  </p>
                  
                  {/* Step Number Indicator */}
                  <div className="mt-8 flex items-center gap-4">
                    <div className="text-6xl font-medium text-[#333]">0{index + 1}</div>
                    <div className="h-px flex-1 bg-[#333]" />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default NCPER;
