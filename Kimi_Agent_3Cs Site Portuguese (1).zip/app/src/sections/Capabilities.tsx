import { useEffect, useRef } from 'react';
import { Warehouse, TrendingUp, ShoppingBag, Calculator, LayoutDashboard } from 'lucide-react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const capabilities = [
  {
    number: '01',
    icon: Warehouse,
    title: 'Otimização de Estoque e Capital',
    description:
      'GMROI, CCC, envelhecimento de estoque, lógica OTB. Transformamos estoque em um sistema financeiro—não um problema de armazém.',
  },
  {
    number: '02',
    icon: TrendingUp,
    title: 'Inteligência de Preços e Comercial',
    description:
      'Lógica de margem vs markup, modelagem de elasticidade, governança de descontos. Cada decisão de preço vinculada ao impacto no P&L.',
  },
  {
    number: '03',
    icon: ShoppingBag,
    title: 'Merchandising e Sortimento',
    description:
      'Papéis de SKU, lógica de profundidade, disciplina de ciclo de vida. Os produtos certos, na profundidade certa, na hora certa.',
  },
  {
    number: '04',
    icon: Calculator,
    title: 'Planejamento e Controle Financeiro',
    description:
      'MFP, previsibilidade de P&L, visibilidade de caixa. Finanças como sistema de decisão, não função de relatórios.',
  },
  {
    number: '05',
    icon: LayoutDashboard,
    title: 'Dashboards de Decisão',
    description:
      'Uma única fonte de verdade. Métricas de nível decisão apenas. Sem ruído. Sem métricas de vaidade. Apenas o que move a agulha.',
  },
];

const Capabilities = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const headerRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement[]>([]);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Header animation
      gsap.fromTo(
        headerRef.current,
        { y: 40, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.6,
          ease: 'expo.out',
          scrollTrigger: {
            trigger: headerRef.current,
            start: 'top 80%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Cards reveal animation - aligned grid
      cardsRef.current.forEach((card, index) => {
        gsap.fromTo(
          card,
          { y: 60, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            duration: 0.7,
            ease: 'back.out(1.2)',
            scrollTrigger: {
              trigger: card,
              start: 'top 85%',
              toggleActions: 'play none none reverse',
            },
            delay: index * 0.1,
          }
        );
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="capabilities"
      className="relative w-full py-32 bg-[#151515]"
    >
      {/* Background Visual */}
      <div className="absolute inset-0 opacity-15 pointer-events-none">
        <img
          src="/data-visual-1.jpg"
          alt=""
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-[#151515] via-transparent to-[#151515]" />
      </div>

      <div className="relative z-10 w-full px-6 lg:px-12">
        {/* Header */}
        <div ref={headerRef} className="text-center mb-20" style={{ opacity: 0 }}>
          <div className="section-label">[ DOMÍNIOS DE DECISÃO ]</div>
          <h2 className="text-h2 text-white">O Que a 3Cs Realmente Faz</h2>
        </div>

        {/* Cards Grid - Aligned 3+2 layout */}
        <div className="max-w-6xl mx-auto">
          {/* Top Row - 3 cards */}
          <div className="grid md:grid-cols-3 gap-6 mb-6">
            {capabilities.slice(0, 3).map((capability, index) => {
              const Icon = capability.icon;
              
              return (
                <div
                  key={index}
                  ref={(el) => { if (el) cardsRef.current[index] = el; }}
                  className="group"
                  style={{ opacity: 0 }}
                >
                  <div className="card-dark h-full flex flex-col hover:scale-[1.03] hover:-translate-y-3 transition-all duration-350">
                    {/* Number */}
                    <div className="text-mono text-[#333] mb-6 group-hover:text-[#666] transition-colors duration-300">
                      {capability.number}
                    </div>

                    {/* Icon */}
                    <div className="w-14 h-14 flex items-center justify-center border border-[#333] mb-6 group-hover:border-[#666] group-hover:rotate-[15deg] group-hover:scale-110 transition-all duration-400">
                      <Icon size={28} className="text-[#999] group-hover:text-white transition-colors duration-300" />
                    </div>

                    {/* Content */}
                    <h3 className="text-h4 text-white mb-4">
                      {capability.title}
                    </h3>
                    <p className="text-[#999] leading-relaxed flex-1 group-hover:text-[#aaa] transition-colors duration-300">
                      {capability.description}
                    </p>

                    {/* Hover Glow */}
                    <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none">
                      <div className="absolute inset-0 bg-gradient-radial from-white/5 to-transparent" />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Bottom Row - 2 cards centered */}
          <div className="grid md:grid-cols-2 gap-6 max-w-4xl mx-auto">
            {capabilities.slice(3, 5).map((capability, index) => {
              const Icon = capability.icon;
              const actualIndex = index + 3;
              
              return (
                <div
                  key={actualIndex}
                  ref={(el) => { if (el) cardsRef.current[actualIndex] = el; }}
                  className="group"
                  style={{ opacity: 0 }}
                >
                  <div className="card-dark h-full flex flex-col hover:scale-[1.03] hover:-translate-y-3 transition-all duration-350">
                    {/* Number */}
                    <div className="text-mono text-[#333] mb-6 group-hover:text-[#666] transition-colors duration-300">
                      {capability.number}
                    </div>

                    {/* Icon */}
                    <div className="w-14 h-14 flex items-center justify-center border border-[#333] mb-6 group-hover:border-[#666] group-hover:rotate-[15deg] group-hover:scale-110 transition-all duration-400">
                      <Icon size={28} className="text-[#999] group-hover:text-white transition-colors duration-300" />
                    </div>

                    {/* Content */}
                    <h3 className="text-h4 text-white mb-4">
                      {capability.title}
                    </h3>
                    <p className="text-[#999] leading-relaxed flex-1 group-hover:text-[#aaa] transition-colors duration-300">
                      {capability.description}
                    </p>

                    {/* Hover Glow */}
                    <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none">
                      <div className="absolute inset-0 bg-gradient-radial from-white/5 to-transparent" />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Capabilities;
