import { useEffect, useRef, useState } from 'react';
import { Send, MessageCircle, MapPin } from 'lucide-react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const Contact = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const headlineRef = useRef<HTMLDivElement>(null);
  const formRef = useRef<HTMLFormElement>(null);
  const infoRef = useRef<HTMLDivElement>(null);

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    message: '',
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Headline animation
      gsap.fromTo(
        headlineRef.current,
        { y: 60, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.7,
          ease: 'expo.out',
          scrollTrigger: {
            trigger: headlineRef.current,
            start: 'top 80%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Form 3D swing in
      gsap.fromTo(
        formRef.current,
        { rotateY: -30, opacity: 0 },
        {
          rotateY: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'back.out(1.2)',
          scrollTrigger: {
            trigger: formRef.current,
            start: 'top 85%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Form fields stagger
      const fields = formRef.current?.querySelectorAll('.form-field');
      if (fields) {
        gsap.fromTo(
          fields,
          { y: 30, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            duration: 0.4,
            ease: 'expo.out',
            stagger: 0.08,
            scrollTrigger: {
              trigger: formRef.current,
              start: 'top 80%',
              toggleActions: 'play none none reverse',
            },
            delay: 0.3,
          }
        );
      }

      // Info fade in
      gsap.fromTo(
        infoRef.current,
        { opacity: 0 },
        {
          opacity: 1,
          duration: 0.5,
          ease: 'smooth',
          scrollTrigger: {
            trigger: infoRef.current,
            start: 'top 90%',
            toggleActions: 'play none none reverse',
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate form submission
    await new Promise((resolve) => setTimeout(resolve, 1500));
    
    setIsSubmitting(false);
    setSubmitted(true);
    setFormData({ name: '', email: '', company: '', message: '' });
  };

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setFormData((prev) => ({
      ...prev,
      [e.target.name]: e.target.value,
    }));
  };

  return (
    <section
      ref={sectionRef}
      id="contact"
      className="relative w-full py-32 bg-[#151515]"
    >
      <div className="w-full px-6 lg:px-12">
        <div className="grid lg:grid-cols-2 gap-16 lg:gap-24 max-w-6xl mx-auto">
          {/* Left Column - Content */}
          <div ref={headlineRef} style={{ opacity: 0 }}>
            <h2 className="text-h2 text-white mb-6">
              Comece com clareza, não uma proposta.
            </h2>
            <p className="text-lg text-[#999] leading-relaxed mb-12">
              Vamos olhar os números juntos. Sem pitch. Apenas uma conversa 
              sobre o que realmente está acontecendo no seu negócio.
            </p>

            {/* Contact Info */}
            <div ref={infoRef} className="space-y-6" style={{ opacity: 0 }}>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 flex items-center justify-center border border-[#333]">
                  <MessageCircle size={20} className="text-[#999]" />
                </div>
                <div>
                  <div className="text-mono text-[#666] mb-1">WHATSAPP</div>
                  <a
                    href="https://wa.me/5511991005401"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-white hover:text-[#999] transition-colors duration-300"
                  >
                    +55 11 99100-5401
                  </a>
                </div>
              </div>

              <div className="flex items-center gap-4">
                <div className="w-12 h-12 flex items-center justify-center border border-[#333]">
                  <MapPin size={20} className="text-[#999]" />
                </div>
                <div>
                  <div className="text-mono text-[#666] mb-1">LOCALIZAÇÃO</div>
                  <div className="text-white">Entrega global, presença local</div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column - Form */}
          <div style={{ perspective: '1000px' }}>
            {submitted ? (
              <div className="card-dark text-center py-16">
                <div className="w-16 h-16 flex items-center justify-center bg-white text-black rounded-full mx-auto mb-6">
                  <Send size={24} />
                </div>
                <h3 className="text-h4 text-white mb-4">Mensagem Enviada</h3>
                <p className="text-[#999]">
                  Obrigado pelo contato. Retornaremos em até 24 horas.
                </p>
              </div>
            ) : (
              <form
                ref={formRef}
                onSubmit={handleSubmit}
                className="space-y-6"
                style={{ opacity: 0, transformStyle: 'preserve-3d' }}
              >
                <div className="form-field relative">
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                    className="input-dark peer"
                    placeholder=" "
                  />
                  <label className="absolute left-0 top-4 text-[#666] transition-all duration-300 peer-focus:-translate-y-6 peer-focus:scale-85 peer-focus:text-white peer-[:not(:placeholder-shown)]:-translate-y-6 peer-[:not(:placeholder-shown)]:scale-85">
                    Nome
                  </label>
                  <div className="absolute bottom-0 left-0 w-0 h-0.5 bg-white transition-all duration-400 peer-focus:w-full" />
                </div>

                <div className="form-field relative">
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    required
                    className="input-dark peer"
                    placeholder=" "
                  />
                  <label className="absolute left-0 top-4 text-[#666] transition-all duration-300 peer-focus:-translate-y-6 peer-focus:scale-85 peer-focus:text-white peer-[:not(:placeholder-shown)]:-translate-y-6 peer-[:not(:placeholder-shown)]:scale-85">
                    Email
                  </label>
                  <div className="absolute bottom-0 left-0 w-0 h-0.5 bg-white transition-all duration-400 peer-focus:w-full" />
                </div>

                <div className="form-field relative">
                  <input
                    type="text"
                    name="company"
                    value={formData.company}
                    onChange={handleChange}
                    className="input-dark peer"
                    placeholder=" "
                  />
                  <label className="absolute left-0 top-4 text-[#666] transition-all duration-300 peer-focus:-translate-y-6 peer-focus:scale-85 peer-focus:text-white peer-[:not(:placeholder-shown)]:-translate-y-6 peer-[:not(:placeholder-shown)]:scale-85">
                    Empresa
                  </label>
                  <div className="absolute bottom-0 left-0 w-0 h-0.5 bg-white transition-all duration-400 peer-focus:w-full" />
                </div>

                <div className="form-field relative">
                  <textarea
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    required
                    rows={4}
                    className="input-dark peer resize-none"
                    placeholder=" "
                  />
                  <label className="absolute left-0 top-4 text-[#666] transition-all duration-300 peer-focus:-translate-y-6 peer-focus:scale-85 peer-focus:text-white peer-[:not(:placeholder-shown)]:-translate-y-6 peer-[:not(:placeholder-shown)]:scale-85">
                    Mensagem
                  </label>
                  <div className="absolute bottom-0 left-0 w-0 h-0.5 bg-white transition-all duration-400 peer-focus:w-full" />
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="btn-secondary w-full justify-center disabled:opacity-50 disabled:cursor-not-allowed group"
                  style={{
                    animation: `submitGlow 3s ease-in-out infinite`,
                  }}
                >
                  {isSubmitting ? (
                    'Enviando...'
                  ) : (
                    <>
                      Enviar Mensagem
                      <Send
                        size={16}
                        className="transition-transform duration-300 group-hover:translate-x-1"
                      />
                    </>
                  )}
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
