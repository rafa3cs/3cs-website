import { useEffect, useRef } from 'react';
import { TrendingUp, Package, BarChart3, Users, EyeOff } from 'lucide-react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const problems = [
  {
    icon: TrendingUp,
    title: 'Crescimento Supera Estrutura',
    description:
      'A receita cresce. Os sistemas não. As decisões ficam mais lentas, arriscadas e reativas.',
    offset: 0,
    rotation: -1,
  },
  {
    icon: Package,
    title: 'Estoque Absorve Caixa Silenciosamente',
    description:
      'O estoque se torna um buraco negro—amarrando capital de giro enquanto envelhece silenciosamente nos armazéns.',
    offset: 40,
    rotation: 1,
  },
  {
    icon: BarChart3,
    title: 'Previsões Não Direcionam Decisões',
    description:
      'Os planos existem, mas não se conectam a preços, compras ou operações em tempo real.',
    offset: 20,
    rotation: -0.5,
  },
  {
    icon: Users,
    title: 'Funções Não Conversam',
    description:
      'Finanças, Operações e Comercial debatem opiniões em vez de números alinhados.',
    offset: 60,
    rotation: 0.5,
  },
  {
    icon: EyeOff,
    title: 'Liderança Carece de Visibilidade',
    description:
      'Quando os problemas surgem, o dano já está feito—as opções são limitadas.',
    offset: 10,
    rotation: -1.5,
  },
];

const Problem = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const titleRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement[]>([]);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Title animation
      gsap.fromTo(
        titleRef.current,
        { y: 60, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.6,
          ease: 'expo.out',
          scrollTrigger: {
            trigger: titleRef.current,
            start: 'top 80%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Cards staggered animation
      cardsRef.current.forEach((card, index) => {
        gsap.fromTo(
          card,
          { x: -100, opacity: 0, rotateY: -20 },
          {
            x: 0,
            opacity: 1,
            rotateY: 0,
            duration: 0.7,
            ease: 'back.out(1.2)',
            scrollTrigger: {
              trigger: card,
              start: 'top 85%',
              toggleActions: 'play none none reverse',
            },
            delay: index * 0.12,
          }
        );
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="problem"
      className="relative w-full py-32 bg-[#151515]"
    >
      <div className="w-full px-6 lg:px-12">
        <div className="grid lg:grid-cols-[0.35fr_0.65fr] gap-12 lg:gap-16">
          {/* Left Column - Title */}
          <div ref={titleRef} className="lg:sticky lg:top-32 lg:self-start" style={{ opacity: 0 }}>
            <div className="section-label">[ A REALIDADE ]</div>
            <h2 className="text-h2 text-white">
              A lacuna entre estratégia e execução
            </h2>
          </div>

          {/* Right Column - Cards */}
          <div className="flex flex-col gap-6">
            {problems.map((problem, index) => {
              const Icon = problem.icon;
              return (
                <div
                  key={index}
                  ref={(el) => { if (el) cardsRef.current[index] = el; }}
                  className="card-dark group border-glow border-glow-hover"
                  style={{
                    transform: `translateX(${problem.offset}px) rotate(${problem.rotation}deg)`,
                    opacity: 0,
                    animation: `borderPulse 4s ease-in-out infinite`,
                    animationDelay: `${index * 0.5}s`,
                  }}
                >
                  <div className="flex items-start gap-6">
                    <div className="flex-shrink-0 w-12 h-12 flex items-center justify-center border border-[#333] group-hover:border-[#666] transition-colors duration-300">
                      <Icon size={24} className="text-[#999] group-hover:text-white transition-colors duration-300" />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-h4 text-white mb-3 group-hover:translate-x-1 transition-transform duration-300">
                        {problem.title}
                      </h3>
                      <p className="text-[#999] leading-relaxed group-hover:text-[#aaa] transition-colors duration-300">
                        {problem.description}
                      </p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Problem;
