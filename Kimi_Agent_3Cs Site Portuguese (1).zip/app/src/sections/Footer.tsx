import { useEffect, useRef } from 'react';
import { Linkedin, Twitter } from 'lucide-react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const footerLinks = {
  company: [
    { label: 'Sobre', href: '#' },
    { label: 'Carreiras', href: '#' },
    { label: 'Contato', href: '#contact' },
  ],
  capabilities: [
    { label: 'Estoque', href: '#capabilities' },
    { label: 'Preços', href: '#capabilities' },
    { label: 'Planejamento', href: '#capabilities' },
    { label: 'Dashboards', href: '#capabilities' },
  ],
  method: [
    { label: 'NCPER', href: '#method' },
    { label: 'Engajamento', href: '#engagement' },
    { label: 'Filosofia', href: '#' },
  ],
  connect: [
    { label: 'LinkedIn', href: '#', icon: Linkedin },
    { label: 'Twitter', href: '#', icon: Twitter },
  ],
};

const Footer = () => {
  const footerRef = useRef<HTMLElement>(null);
  const borderRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Border line draw
      gsap.fromTo(
        borderRef.current,
        { scaleX: 0 },
        {
          scaleX: 1,
          duration: 0.8,
          ease: 'expo.out',
          scrollTrigger: {
            trigger: footerRef.current,
            start: 'top 95%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Content fade in
      gsap.fromTo(
        contentRef.current,
        { y: 20, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.5,
          ease: 'smooth',
          scrollTrigger: {
            trigger: footerRef.current,
            start: 'top 90%',
            toggleActions: 'play none none reverse',
          },
          delay: 0.2,
        }
      );
    }, footerRef);

    return () => ctx.revert();
  }, []);

  return (
    <footer
      ref={footerRef}
      className="relative w-full bg-black pt-20 pb-8"
    >
      {/* Top Border */}
      <div
        ref={borderRef}
        className="absolute top-0 left-0 right-0 h-px bg-[#333]"
        style={{ transformOrigin: 'left', transform: 'scaleX(0)' }}
      />

      <div ref={contentRef} className="w-full px-6 lg:px-12" style={{ opacity: 0 }}>
        {/* Main Footer Content */}
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-8 lg:gap-12 mb-16">
          {/* Logo Column */}
          <div className="col-span-2 md:col-span-4 lg:col-span-1 mb-8 lg:mb-0">
            <a
              href="#"
              className="text-3xl font-medium tracking-[-0.05em] text-white hover:opacity-80 transition-opacity"
              onClick={(e) => {
                e.preventDefault();
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
            >
              3Cs
            </a>
            <p className="text-sm text-[#666] mt-4 max-w-xs">
              Inteligência de decisão para negócios capital-intensivos.
            </p>
          </div>

          {/* Company Links */}
          <div>
            <h4 className="text-mono text-[#666] mb-4">EMPRESA</h4>
            <ul className="space-y-3">
              {footerLinks.company.map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    className="text-[#999] hover:text-white hover:translate-x-1 inline-block transition-all duration-200"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Capabilities Links */}
          <div>
            <h4 className="text-mono text-[#666] mb-4">CAPACIDADES</h4>
            <ul className="space-y-3">
              {footerLinks.capabilities.map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    className="text-[#999] hover:text-white hover:translate-x-1 inline-block transition-all duration-200"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Method Links */}
          <div>
            <h4 className="text-mono text-[#666] mb-4">MÉTODO</h4>
            <ul className="space-y-3">
              {footerLinks.method.map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    className="text-[#999] hover:text-white hover:translate-x-1 inline-block transition-all duration-200"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Connect Links */}
          <div>
            <h4 className="text-mono text-[#666] mb-4">CONECTE</h4>
            <ul className="space-y-3">
              {footerLinks.connect.map((link) => {
                const Icon = link.icon;
                return (
                  <li key={link.label}>
                    <a
                      href={link.href}
                      className="text-[#999] hover:text-white hover:translate-x-1 inline-flex items-center gap-2 transition-all duration-200"
                    >
                      {Icon && <Icon size={16} />}
                      {link.label}
                    </a>
                  </li>
                );
              })}
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-[#333] flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="text-sm text-[#666]">
            © {new Date().getFullYear()} 3Cs. Todos os direitos reservados.
          </div>
          <div className="flex gap-6">
            <a
              href="#"
              className="text-sm text-[#666] hover:text-white transition-colors duration-200"
            >
              Política de Privacidade
            </a>
            <a
              href="#"
              className="text-sm text-[#666] hover:text-white transition-colors duration-200"
            >
              Termos de Serviço
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
