import { useEffect, useRef, useState } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const principles = [
  {
    text: 'Finanças são um sistema de decisões, não relatórios.',
    emphasis: ['decisões', 'não relatórios'],
    image: '/philosophy-1.jpg',
  },
  {
    text: 'Disciplina torna ambição sustentável.',
    emphasis: ['Disciplina', 'sustentável'],
    image: '/philosophy-2.jpg',
  },
  {
    text: 'Suposições tornadas explícitas reduzem conflito.',
    emphasis: ['explícitas', 'reduzem conflito'],
    image: '/philosophy-3.jpg',
  },
  {
    text: 'Boas estratégias falham sem proteção de execução.',
    emphasis: ['proteção de execução'],
    image: '/philosophy-4.jpg',
  },
  {
    text: 'Estoque sempre diz a verdade—se você souber como ler.',
    emphasis: ['verdade'],
    image: '/philosophy-5.jpg',
  },
];

const Philosophy = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const headerRef = useRef<HTMLDivElement>(null);
  const sliderRef = useRef<HTMLDivElement>(null);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isHovered, setIsHovered] = useState(false);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Header animation
      gsap.fromTo(
        headerRef.current,
        { y: 40, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.6,
          ease: 'expo.out',
          scrollTrigger: {
            trigger: headerRef.current,
            start: 'top 80%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Slider animation
      gsap.fromTo(
        sliderRef.current,
        { y: 60, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'expo.out',
          scrollTrigger: {
            trigger: sliderRef.current,
            start: 'top 80%',
            toggleActions: 'play none none reverse',
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  // Auto-play slider
  useEffect(() => {
    if (isHovered) return;
    
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % principles.length);
    }, 5000);

    return () => clearInterval(interval);
  }, [isHovered]);

  const goToSlide = (index: number) => {
    setCurrentIndex(index);
  };

  const goToPrev = () => {
    setCurrentIndex((prev) => (prev - 1 + principles.length) % principles.length);
  };

  const goToNext = () => {
    setCurrentIndex((prev) => (prev + 1) % principles.length);
  };

  const renderPrincipleText = (principle: typeof principles[0]) => {
    const words = principle.text.split(' ');
    
    return words.map((word, wIndex) => {
      const cleanWord = word.replace(/[.,—]/g, '');
      const isEmphasis = principle.emphasis.some(
        (emph) => cleanWord.toLowerCase().includes(emph.toLowerCase()) ||
                 emph.toLowerCase().includes(cleanWord.toLowerCase())
      );
      
      return (
        <span
          key={wIndex}
          className={`inline-block mr-[0.3em] transition-all duration-500 ${
            isEmphasis
              ? 'text-white'
              : 'text-[#666]'
          }`}
        >
          {word}
        </span>
      );
    });
  };

  return (
    <section
      ref={sectionRef}
      className="relative w-full py-32 bg-[#151515] overflow-hidden"
    >
      <div className="relative z-10 w-full px-6 lg:px-12">
        {/* Header */}
        <div ref={headerRef} className="text-center mb-16" style={{ opacity: 0 }}>
          <div className="section-label">[ PRINCÍPIOS ]</div>
          <h2 className="text-h2 text-white">Filosofia</h2>
        </div>

        {/* Slider */}
        <div 
          ref={sliderRef}
          className="relative max-w-6xl mx-auto"
          style={{ opacity: 0 }}
          onMouseEnter={() => setIsHovered(true)}
          onMouseLeave={() => setIsHovered(false)}
        >
          {/* Main Slider Container */}
          <div className="relative overflow-hidden">
            {/* Slides */}
            <div 
              className="flex transition-transform duration-700 ease-out"
              style={{ transform: `translateX(-${currentIndex * 100}%)` }}
            >
              {principles.map((principle, index) => (
                <div
                  key={index}
                  className="w-full flex-shrink-0"
                >
                  <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 items-center">
                    {/* Image Side */}
                    <div className="relative aspect-[16/10] overflow-hidden group">
                      <img
                        src={principle.image}
                        alt={`Princípio ${index + 1}`}
                        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-[#151515]/40 to-transparent" />
                      
                      {/* Slide Number */}
                      <div className="absolute bottom-4 left-4 text-6xl font-medium text-white/20">
                        0{index + 1}
                      </div>
                    </div>

                    {/* Text Side */}
                    <div className="py-8">
                      <p className="text-[clamp(1.5rem,3.5vw,2.5rem)] font-medium leading-[1.3] tracking-[-0.03em]">
                        {renderPrincipleText(principle)}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Navigation Arrows */}
          <button
            onClick={goToPrev}
            className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-4 lg:-translate-x-16 w-12 h-12 flex items-center justify-center border border-[#333] bg-[#151515] text-white hover:border-[#666] hover:bg-[#1a1a1a] transition-all duration-300 z-10"
            aria-label="Slide anterior"
          >
            <ChevronLeft size={24} />
          </button>
          
          <button
            onClick={goToNext}
            className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-4 lg:translate-x-16 w-12 h-12 flex items-center justify-center border border-[#333] bg-[#151515] text-white hover:border-[#666] hover:bg-[#1a1a1a] transition-all duration-300 z-10"
            aria-label="Próximo slide"
          >
            <ChevronRight size={24} />
          </button>

          {/* Dots Indicator */}
          <div className="flex justify-center gap-3 mt-8">
            {principles.map((_, index) => (
              <button
                key={index}
                onClick={() => goToSlide(index)}
                className={`w-2 h-2 transition-all duration-300 ${
                  index === currentIndex
                    ? 'bg-white w-8'
                    : 'bg-[#333] hover:bg-[#666]'
                }`}
                aria-label={`Ir para slide ${index + 1}`}
              />
            ))}
          </div>

          {/* Progress Bar */}
          <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#333] mt-8">
            <div 
              className="h-full bg-white transition-all duration-500"
              style={{ width: `${((currentIndex + 1) / principles.length) * 100}%` }}
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default Philosophy;
